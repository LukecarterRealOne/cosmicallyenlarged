package dev.cosmicgun;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

/**
 * Simulates flying celestial bodies, their lingering fields and all the visual effects
 * (3D particle shapes, muzzle flash, shockwaves, sparks, vortex swirls) on the server.
 */
public final class ShotManager {
    private ShotManager() {}

    /** Set to true if you want impacts to destroy blocks like TNT. Default: entities only. */
    private static final boolean DESTROY_BLOCKS = false;

    private static final int MAX_FLIGHT_TICKS = 120;
    private static final int SUBSTEPS = 3;
    /** Safety cap so spamming the gun can't flood the server with particle packets. */
    private static final int MAX_SHOTS = 24;

    // ------------------------------------------------------------------ data

    private static final class Shot {
        final ServerLevel level;
        final CelestialBodies.Body body;
        final UUID owner;
        Vec3 pos;
        Vec3 vel;
        int life = MAX_FLIGHT_TICKS;

        Shot(ServerLevel level, CelestialBodies.Body body, UUID owner, Vec3 pos, Vec3 vel) {
            this.level = level;
            this.body = body;
            this.owner = owner;
            this.pos = pos;
            this.vel = vel;
        }
    }

    private static final class Zone {
        final ServerLevel level;
        final CelestialBodies.Body body;
        final UUID owner;
        final Vec3 pos;
        int ticks;

        Zone(ServerLevel level, CelestialBodies.Body body, UUID owner, Vec3 pos, int ticks) {
            this.level = level;
            this.body = body;
            this.owner = owner;
            this.pos = pos;
            this.ticks = ticks;
        }
    }

    /** An expanding shockwave: a flat ring on the ground plane plus (for big hits) a spherical shell. */
    private static final class Wave {
        final ServerLevel level;
        final Vec3 pos;
        final double maxRadius;
        final int duration;
        final ParticleOptions ringParticle;
        final ParticleOptions shellParticle;
        final boolean shell;
        int age = 0;

        Wave(ServerLevel level, Vec3 pos, double maxRadius, int duration,
             ParticleOptions ringParticle, ParticleOptions shellParticle, boolean shell) {
            this.level = level;
            this.pos = pos;
            this.maxRadius = maxRadius;
            this.duration = duration;
            this.ringParticle = ringParticle;
            this.shellParticle = shellParticle;
            this.shell = shell;
        }
    }

    private static final List<Shot> SHOTS = new ArrayList<>();
    private static final List<Zone> ZONES = new ArrayList<>();
    private static final List<Wave> WAVES = new ArrayList<>();

    public static void clear() {
        SHOTS.clear();
        ZONES.clear();
        WAVES.clear();
    }

    // ------------------------------------------------------------------ firing

    public static void fire(ServerLevel level, Player player, CelestialBodies.Body body) {
        Vec3 look = player.getLookAngle();
        Vec3 start = player.getEyePosition().add(look.scale(1.3)).add(0, -0.15, 0);

        if (SHOTS.size() >= MAX_SHOTS) SHOTS.remove(0);
        SHOTS.add(new Shot(level, body, player.getUUID(), start, look.scale(body.speed())));

        muzzleFlash(level, start, look, body);
    }

    /** Muzzle flash: a short forward cone of sparks, a bright core burst and a small ring. */
    private static void muzzleFlash(ServerLevel level, Vec3 start, Vec3 look, CelestialBodies.Body body) {
        Shapes.Basis basis = Shapes.Basis.of(look);
        Shapes.cone(start, basis, 0.7, 2.2, true, 8, 3, 0.0,
                (x, y, z) -> level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0, 0, 0, 0.0));
        Shapes.ring(start.add(look.scale(0.6)), basis, 0.55, 14, 0.0, 0.0,
                (x, y, z) -> level.sendParticles(body.trail(), x, y, z, 1, 0, 0, 0, 0.0));
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, start.x, start.y, start.z, 14, 0.15, 0.15, 0.15, 0.35);
        level.sendParticles(body.core(), start.x, start.y, start.z, 6, 0.1, 0.1, 0.1, 0.05);
    }

    // ------------------------------------------------------------------ tick

    public static void tick() {
        Iterator<Shot> shotIt = SHOTS.iterator();
        while (shotIt.hasNext()) {
            if (!tickShot(shotIt.next())) shotIt.remove();
        }
        Iterator<Zone> zoneIt = ZONES.iterator();
        while (zoneIt.hasNext()) {
            if (!tickZone(zoneIt.next())) zoneIt.remove();
        }
        Iterator<Wave> waveIt = WAVES.iterator();
        while (waveIt.hasNext()) {
            if (!tickWave(waveIt.next())) waveIt.remove();
        }
    }

    /** @return true while the shot is still flying */
    private static boolean tickShot(Shot s) {
        CelestialBodies.Body b = s.body;
        s.life--;
        s.vel = s.vel.add(0, -b.gravity(), 0);
        Vec3 step = s.vel.scale(1.0 / SUBSTEPS);

        for (int i = 0; i < SUBSTEPS; i++) {
            Vec3 next = s.pos.add(step);

            BlockHitResult hit = s.level.clip(new ClipContext(
                    s.pos, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, CollisionContext.empty()));
            if (hit.getType() != HitResult.Type.MISS) {
                impact(s, hit.getLocation());
                return false;
            }

            double h = 0.3 + b.size() * 0.5;
            AABB box = new AABB(next.x - h, next.y - h, next.z - h, next.x + h, next.y + h, next.z + h);
            List<LivingEntity> hits = s.level.getEntitiesOfClass(
                    LivingEntity.class, box, e -> e.isAlive() && !e.getUUID().equals(s.owner));
            if (!hits.isEmpty()) {
                impact(s, next);
                return false;
            }

            s.pos = next;
            // continuous trail along the path
            s.level.sendParticles(b.trail(), s.pos.x, s.pos.y, s.pos.z, 1, 0.08, 0.08, 0.08, 0.01);
        }

        drawBody(s);

        if (s.life <= 0 || s.pos.y < s.level.getMinY() - 32) {
            // Out of range: fizzle out in a small burst.
            s.level.sendParticles(b.trail(), s.pos.x, s.pos.y, s.pos.z, 30, 0.5, 0.5, 0.5, 0.05);
            return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ drawing the body

    private static void drawBody(Shot s) {
        CelestialBodies.Body b = s.body;
        ServerLevel level = s.level;
        Vec3 p = s.pos;
        Shapes.Basis basis = Shapes.Basis.of(s.vel);
        double spin = level.getGameTime() * 0.22;
        double radius = 0.3 + b.size() * 0.55;

        Shapes.Emit core = (x, y, z) -> level.sendParticles(b.core(), x, y, z, 1, 0, 0, 0, 0.0);
        Shapes.Emit accent = (x, y, z) -> level.sendParticles(b.trail(), x, y, z, 1, 0, 0, 0, 0.0);
        int points = Math.min(56, 14 + (int) (b.size() * 14));

        switch (b.shape()) {
            case SPHERE -> Shapes.sphere(p, basis, radius, points, spin, core);
            case CUBE -> Shapes.cube(p, basis, radius * 0.7, spin, core);
            case SQUARE_PYRAMID -> Shapes.squarePyramid(p, basis, radius * 0.8, spin, core);
            case TRI_PYRAMID -> Shapes.triangularPyramid(p, basis, radius * 0.9, spin, core);
            case TRI_PRISM -> Shapes.triangularPrism(p, basis, radius * 0.7, spin, core);
            case CYLINDER -> Shapes.cylinder(p, basis, radius * 0.35, radius * 1.8, 6, 6, spin, core);
            case TORUS -> {
                // Accretion-disk / galactic-disk look: a glowing donut with a bright hub in the middle.
                Shapes.torus(p, basis, radius * 1.1, radius * 0.28, 16, 3, spin, core);
                level.sendParticles(b.trail(), p.x, p.y, p.z, 3, radius * 0.2, radius * 0.2, radius * 0.2, 0.01);
            }
        }

        if (b.ring()) {
            Shapes.ring(p, basis, radius * 1.9, 20, 0.22, -spin, (x, y, z) ->
                    level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0, 0, 0, 0.0));
        }
        if (b.hasTail()) {
            Vec3 back = s.vel.scale(-1.0);
            Shapes.cone(p, Shapes.Basis.of(back), radius * 0.9, 4.5 + b.size() * 2.0, false, 6, 5, spin, accent);
        }
        if (b.hasJets()) {
            Shapes.Basis jet = basis.alongUp();
            double len = 3.0 + b.size() * 2.0;
            Shapes.cone(p, jet, radius * 0.4, len, true, 5, 4, spin, (x, y, z) ->
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 1, 0, 0, 0, 0.0));
            Shapes.cone(p, jet, radius * 0.4, -len, true, 5, 4, spin, (x, y, z) ->
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, x, y, z, 1, 0, 0, 0, 0.0));
        }
    }

    // ------------------------------------------------------------------ impact

    private static void impact(Shot s, Vec3 p) {
        CelestialBodies.Body b = s.body;
        ServerLevel level = s.level;
        double r = b.radius();

        // energy burst: dense core cloud + fast radial sparks
        level.sendParticles(b.core(), p.x, p.y, p.z, 60, r * 0.35, r * 0.25, r * 0.35, 0.12);
        level.sendParticles(b.trail(), p.x, p.y, p.z, 60, r * 0.4, r * 0.3, r * 0.4, 0.25);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 50, 0.2, 0.2, 0.2, 0.9);
        level.sendParticles(ParticleTypes.FIREWORK, p.x, p.y, p.z, 30, 0.2, 0.2, 0.2, 0.55);

        // flash: a quick bright sphere
        Shapes.sphere(p, Shapes.Basis.of(new Vec3(0, 1, 0)), 0.8 + b.size() * 0.5, 24, 0.0,
                (x, y, z) -> level.sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0, 0, 0, 0.05));

        // shockwave (ring on the ground plane, shell for big hits)
        WAVES.add(new Wave(level, p, Math.max(3.0, r), 8 + (int) b.power(),
                b.core(), ParticleTypes.END_ROD, b.power() >= 4.0f));

        if (b.power() >= 3.0f) {
            level.sendParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 25, r * 0.2, r * 0.3, r * 0.2, 0.08);
        }

        if (b.power() > 0) {
            level.explode(null, p.x, p.y, p.z, b.power(),
                    DESTROY_BLOCKS ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
        }

        if (b.zoneTicks() > 0) {
            ZONES.add(new Zone(level, b, s.owner, p, b.zoneTicks()));
        } else {
            applyEffect(level, b, p, s.owner, 1.0, 120);
        }
    }

    private static boolean tickWave(Wave w) {
        w.age++;
        double t = (double) w.age / w.duration;
        double radius = w.maxRadius * t;
        Shapes.Basis up = Shapes.Basis.of(new Vec3(0, 1, 0));
        int points = Math.min(72, 10 + (int) (radius * 5));

        // flat ring hugging the impact height
        Shapes.ring(w.pos, up, radius, points, 0.0, 0.0, (x, y, z) ->
                w.level.sendParticles(w.ringParticle, x, y, z, 1, 0, 0.02, 0, 0.0));

        if (w.shell) {
            Shapes.sphere(w.pos, up, radius * 0.9, Math.min(60, 12 + (int) (radius * 3)), w.age * 0.3, (x, y, z) ->
                    w.level.sendParticles(w.shellParticle, x, y, z, 1, 0, 0, 0, 0.0));
        }
        return w.age < w.duration;
    }

    // ------------------------------------------------------------------ lingering fields

    private static boolean tickZone(Zone z) {
        CelestialBodies.Body b = z.body;
        z.ticks--;
        long time = z.level.getGameTime();
        double r = b.radius();
        boolean inward = b.effect() == CelestialBodies.Effect.PULL;

        // vortex: three spiral arms flowing in (pull) or out (everything else)
        Shapes.Basis up = Shapes.Basis.of(new Vec3(0, 1, 0));
        for (int arm = 0; arm < 3; arm++) {
            for (int k = 0; k < 7; k++) {
                double t = k / 7.0;
                double flow = inward ? t - time * 0.03 : t + time * 0.03;
                double f = flow - Math.floor(flow);
                double rad = r * f;
                double ang = time * 0.25 + arm * (Math.PI * 2.0 / 3.0) + f * 3.2;
                double yOff = Math.sin(time * 0.1 + f * 4.0) * 0.4;
                Vec3 q = z.pos.add(Math.cos(ang) * rad, yOff, Math.sin(ang) * rad);
                z.level.sendParticles(b.core(), q.x, q.y, q.z, 1, 0, 0, 0, 0.0);
            }
        }
        if (z.ticks % 2 == 0) {
            Shapes.torus(z.pos, up, Math.min(r * 0.35, 3.0), 0.25, 14, 3, time * 0.3, (x, y, z2) ->
                    z.level.sendParticles(b.trail(), x, y, z2, 1, 0, 0, 0, 0.0));
        }

        boolean physics = b.effect() == CelestialBodies.Effect.PULL || b.effect() == CelestialBodies.Effect.PUSH;
        if (physics) {
            applyEffect(z.level, b, z.pos, z.owner, 0.22, 0);
        } else if (z.ticks % 10 == 0) {
            applyEffect(z.level, b, z.pos, z.owner, 1.0, 60);
        }
        return z.ticks > 0;
    }

    // ------------------------------------------------------------------ gameplay effects

    private static void applyEffect(ServerLevel level, CelestialBodies.Body b, Vec3 c, UUID owner, double strength, int duration) {
        if (b.effect() == CelestialBodies.Effect.NONE) return;

        double r = b.radius();
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        List<LivingEntity> targets = level.getEntitiesOfClass(
                LivingEntity.class, box, e -> e.isAlive() && !e.getUUID().equals(owner) && e.position().distanceTo(c) <= r);

        for (LivingEntity e : targets) {
            switch (b.effect()) {
                case BURN -> e.setRemainingFireTicks(Math.max(100, duration));
                case FREEZE -> {
                    e.setTicksFrozen(260);
                    e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, duration, 2));
                }
                case PULL, PUSH -> {
                    Vec3 d = c.subtract(e.position().add(0, e.getBbHeight() * 0.5, 0));
                    double dist = Math.max(d.length(), 0.75);
                    Vec3 dir = d.scale(1.0 / dist);
                    double sign = b.effect() == CelestialBodies.Effect.PULL ? 1.0 : -1.0;
                    double force = strength * (b.effect() == CelestialBodies.Effect.PUSH ? 2.2 : 1.0);
                    e.push(dir.x * force * sign, dir.y * force * sign * 0.8 + (sign < 0 ? 0.35 * strength : 0), dir.z * force * sign);
                }
                case BLIND -> e.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, duration, 0));
                case POISON -> e.addEffect(new MobEffectInstance(MobEffects.POISON, duration, 1));
                case NAUSEA -> e.addEffect(new MobEffectInstance(MobEffects.NAUSEA, duration, 0));
                case GLOW -> e.addEffect(new MobEffectInstance(MobEffects.GLOWING, duration * 2, 0));
                case LEVITATE -> e.addEffect(new MobEffectInstance(MobEffects.LEVITATION, Math.max(40, duration / 2), 0));
                case SLOW -> e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, duration, 3));
                case WITHER -> e.addEffect(new MobEffectInstance(MobEffects.WITHER, duration, 1));
                case REGEN -> e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 1));
                case WEAKEN -> e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, 1));
                case DARKEN -> e.addEffect(new MobEffectInstance(MobEffects.DARKNESS, duration, 0));
                default -> { }
            }
        }
    }
}
