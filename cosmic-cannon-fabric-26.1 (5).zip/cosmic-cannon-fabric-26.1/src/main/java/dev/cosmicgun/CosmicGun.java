package dev.cosmicgun;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;

import java.util.function.Function;

/** COSMIC CANNON: a sci-fi gun that fires planets, moons, stars, comets, black holes and more. */
public final class CosmicGun implements ModInitializer {
    public static final String MOD_ID = "cosmicgun";

    public static Item COSMIC_CANNON;

    @Override
    public void onInitialize() {
        COSMIC_CANNON = register("cosmic_cannon", CosmicCannonItem::new, new Item.Properties().stacksTo(1));

        ServerTickEvents.END_SERVER_TICK.register(server -> ShotManager.tick());
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> ShotManager.clear());
    }

    private static <T extends Item> T register(String name, Function<Item.Properties, T> factory, Item.Properties properties) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(properties.setId(key)));
    }
}
