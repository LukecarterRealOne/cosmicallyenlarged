package dev.cosmicgun;

import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Every celestial object the cannon can fire. */
public final class CelestialBodies {
    private CelestialBodies() {}

    /** The 3D primitive used to draw the body in flight. */
    public enum Shape { SPHERE, CUBE, CYLINDER, TORUS, SQUARE_PYRAMID, TRI_PYRAMID, TRI_PRISM }

    /** Non-sphere shapes. Everything not listed here is drawn as a sphere. */
    private static final Map<String, Shape> SHAPES = Map.ofEntries(
            Map.entry("Asteroid", Shape.CUBE),
            Map.entry("Meteor", Shape.SQUARE_PYRAMID),
            Map.entry("Phobos", Shape.TRI_PRISM),
            Map.entry("Deimos", Shape.TRI_PYRAMID),
            Map.entry("'Oumuamua", Shape.CYLINDER),
            Map.entry("Black Hole", Shape.TORUS),
            Map.entry("Magnetar", Shape.TORUS),
            Map.entry("Andromeda Galaxy", Shape.TORUS),
            Map.entry("Milky Way", Shape.TORUS)
    );

    /** Bodies that drag a comet-style cone tail. */
    private static final Set<String> TAILS = Set.of("Meteor", "Halley's Comet");

    /** Bodies that shoot a pair of jets out of their poles. */
    private static final Set<String> JETS = Set.of("Pulsar", "Quasar", "Black Hole", "Magnetar");

    public enum Effect { NONE, BURN, FREEZE, PULL, PUSH, BLIND, POISON, NAUSEA, GLOW, LEVITATE, SLOW, WITHER, REGEN, WEAKEN, DARKEN }

    /**
     * @param core      particles making up the body itself
     * @param trail     particles left behind in flight
     * @param speed     blocks per tick
     * @param gravity   downward acceleration per tick
     * @param power     explosion power on impact (0 = none)
     * @param zoneTicks how long a lingering field stays after impact (0 = none)
     * @param radius    effect radius in blocks
     * @param size      visual size of the body in flight
     * @param ring      draws a ring around the body (Saturn-style)
     */
    public record Body(String name, String kind, ParticleOptions core, ParticleOptions trail,
                       double speed, double gravity, float power, Effect effect,
                       int zoneTicks, double radius, double size, boolean ring) {
        public Shape shape() { return SHAPES.getOrDefault(name, Shape.SPHERE); }
        public boolean hasTail() { return TAILS.contains(name); }
        public boolean hasJets() { return JETS.contains(name); }
    }

    public static final List<Body> ALL = new ArrayList<>();

    private static void add(String name, String kind, ParticleOptions core, ParticleOptions trail,
                            double speed, double gravity, float power, Effect effect,
                            int zoneTicks, double radius, double size, boolean ring) {
        ALL.add(new Body(name, kind, core, trail, speed, gravity, power, effect, zoneTicks, radius, size, ring));
    }

    static {
        // ---------- Planets ----------
        add("Mercury", "Planet", ParticleTypes.ASH, ParticleTypes.FLAME, 2.2, 0.010, 1.5f, Effect.BURN, 0, 4, 0.4, false);
        add("Venus", "Planet", ParticleTypes.LARGE_SMOKE, ParticleTypes.CRIMSON_SPORE, 1.8, 0.015, 2.0f, Effect.POISON, 0, 5, 0.6, false);
        add("Earth", "Planet", ParticleTypes.HAPPY_VILLAGER, ParticleTypes.CLOUD, 1.8, 0.015, 2.0f, Effect.REGEN, 0, 5, 0.6, false);
        add("Moon", "Natural satellite", ParticleTypes.WHITE_ASH, ParticleTypes.END_ROD, 1.8, 0.004, 1.5f, Effect.LEVITATE, 0, 5, 0.4, false);
        add("Mars", "Planet", ParticleTypes.CRIMSON_SPORE, ParticleTypes.ASH, 1.8, 0.015, 2.0f, Effect.BURN, 0, 5, 0.5, false);
        add("Jupiter", "Gas giant", ParticleTypes.CLOUD, ParticleTypes.SMOKE, 1.3, 0.030, 3.5f, Effect.SLOW, 0, 8, 1.4, false);
        add("Saturn", "Gas giant", ParticleTypes.CLOUD, ParticleTypes.END_ROD, 1.3, 0.025, 3.0f, Effect.LEVITATE, 0, 7, 1.1, true);
        add("Uranus", "Ice giant", ParticleTypes.SNOWFLAKE, ParticleTypes.CLOUD, 1.4, 0.020, 2.5f, Effect.FREEZE, 0, 7, 0.9, true);
        add("Neptune", "Ice giant", ParticleTypes.GLOW_SQUID_INK, ParticleTypes.SNOWFLAKE, 1.4, 0.020, 2.5f, Effect.SLOW, 0, 7, 0.9, false);
        add("Pluto", "Dwarf planet", ParticleTypes.SNOWFLAKE, ParticleTypes.WHITE_ASH, 1.6, 0.008, 1.5f, Effect.FREEZE, 0, 4, 0.3, false);

        // ---------- Moons ----------
        add("Io", "Moon of Jupiter", ParticleTypes.LAVA, ParticleTypes.FLAME, 1.9, 0.010, 2.0f, Effect.BURN, 0, 5, 0.4, false);
        add("Europa", "Moon of Jupiter", ParticleTypes.SNOWFLAKE, ParticleTypes.END_ROD, 1.9, 0.010, 1.5f, Effect.FREEZE, 0, 5, 0.4, false);
        add("Ganymede", "Moon of Jupiter", ParticleTypes.CLOUD, ParticleTypes.ASH, 1.7, 0.012, 2.0f, Effect.SLOW, 0, 5, 0.5, false);
        add("Callisto", "Moon of Jupiter", ParticleTypes.ASH, ParticleTypes.SMOKE, 1.7, 0.012, 2.0f, Effect.WEAKEN, 0, 5, 0.5, false);
        add("Titan", "Moon of Saturn", ParticleTypes.LARGE_SMOKE, ParticleTypes.SMOKE, 1.6, 0.015, 2.0f, Effect.POISON, 0, 6, 0.6, false);
        add("Enceladus", "Moon of Saturn", ParticleTypes.SNOWFLAKE, ParticleTypes.CLOUD, 2.0, 0.008, 1.5f, Effect.FREEZE, 0, 5, 0.3, false);
        add("Triton", "Moon of Neptune", ParticleTypes.SNOWFLAKE, ParticleTypes.GLOW_SQUID_INK, 1.9, 0.010, 1.5f, Effect.FREEZE, 0, 5, 0.4, false);
        add("Deimos", "Moon of Mars", ParticleTypes.ASH, ParticleTypes.WHITE_ASH, 2.3, 0.004, 1.0f, Effect.SLOW, 0, 4, 0.2, false);
        add("Phobos", "Moon of Mars", ParticleTypes.ASH, ParticleTypes.SMOKE, 2.3, 0.004, 1.0f, Effect.NAUSEA, 0, 4, 0.2, false);

        // ---------- Small bodies ----------
        add("Ceres", "Dwarf planet", ParticleTypes.ASH, ParticleTypes.WHITE_ASH, 1.8, 0.008, 1.5f, Effect.SLOW, 0, 4, 0.3, false);
        add("Halley's Comet", "Comet", ParticleTypes.END_ROD, ParticleTypes.SNOWFLAKE, 2.6, 0.000, 2.0f, Effect.FREEZE, 0, 6, 0.5, false);
        add("Asteroid", "Asteroid", ParticleTypes.SMOKE, ParticleTypes.ASH, 2.2, 0.020, 3.0f, Effect.NONE, 0, 4, 0.4, false);
        add("Meteor", "Meteoroid", ParticleTypes.FLAME, ParticleTypes.LARGE_SMOKE, 2.4, 0.030, 3.5f, Effect.BURN, 0, 6, 0.4, false);
        add("Eris", "Dwarf planet", ParticleTypes.SNOWFLAKE, ParticleTypes.WHITE_ASH, 1.6, 0.008, 1.5f, Effect.FREEZE, 0, 4, 0.3, false);
        add("'Oumuamua", "Interstellar object", ParticleTypes.ELECTRIC_SPARK, ParticleTypes.END_ROD, 3.0, 0.000, 1.0f, Effect.GLOW, 0, 6, 0.3, false);

        // ---------- Stars ----------
        add("The Sun", "G-type star", ParticleTypes.FLAME, ParticleTypes.LAVA, 1.2, 0.000, 5.0f, Effect.BURN, 100, 9, 1.8, false);
        add("Proxima Centauri", "Red dwarf", ParticleTypes.CRIMSON_SPORE, ParticleTypes.FLAME, 1.8, 0.000, 3.0f, Effect.BURN, 0, 6, 0.8, false);
        add("Sirius", "Binary star", ParticleTypes.END_ROD, ParticleTypes.FIREWORK, 1.7, 0.000, 4.0f, Effect.BLIND, 0, 8, 1.2, false);
        add("Betelgeuse", "Red supergiant", ParticleTypes.LAVA, ParticleTypes.FLAME, 1.1, 0.000, 5.5f, Effect.BURN, 80, 10, 2.2, false);
        add("Rigel", "Blue supergiant", ParticleTypes.SOUL_FIRE_FLAME, ParticleTypes.ELECTRIC_SPARK, 1.4, 0.000, 4.5f, Effect.BURN, 0, 9, 1.6, false);
        add("White Dwarf", "Stellar remnant", ParticleTypes.END_ROD, ParticleTypes.WHITE_ASH, 1.8, 0.000, 3.0f, Effect.BLIND, 0, 6, 0.5, false);
        add("Brown Dwarf", "Substellar object", ParticleTypes.ASH, ParticleTypes.SMOKE, 1.6, 0.010, 1.5f, Effect.SLOW, 0, 5, 0.6, false);
        add("Neutron Star", "Stellar remnant", ParticleTypes.ELECTRIC_SPARK, ParticleTypes.SOUL_FIRE_FLAME, 1.9, 0.000, 4.0f, Effect.WEAKEN, 0, 7, 0.4, false);
        add("Pulsar", "Rotating neutron star", ParticleTypes.ELECTRIC_SPARK, ParticleTypes.END_ROD, 2.0, 0.000, 3.0f, Effect.GLOW, 80, 9, 0.5, true);
        add("Magnetar", "Magnetic neutron star", ParticleTypes.ELECTRIC_SPARK, ParticleTypes.PORTAL, 1.9, 0.000, 3.5f, Effect.NAUSEA, 80, 9, 0.5, true);

        // ---------- Extreme events & objects ----------
        add("Supernova", "Stellar explosion", ParticleTypes.EXPLOSION_EMITTER, ParticleTypes.FIREWORK, 1.5, 0.000, 7.0f, Effect.PUSH, 0, 14, 1.5, false);
        add("Gamma-Ray Burst", "Cosmic explosion", ParticleTypes.SONIC_BOOM, ParticleTypes.ELECTRIC_SPARK, 3.0, 0.000, 6.0f, Effect.WITHER, 0, 12, 0.8, false);
        add("Quasar", "Active galactic nucleus", ParticleTypes.END_ROD, ParticleTypes.PORTAL, 1.5, 0.000, 3.0f, Effect.PULL, 100, 13, 1.5, true);
        add("Black Hole", "Singularity", ParticleTypes.SQUID_INK, ParticleTypes.REVERSE_PORTAL, 1.2, 0.000, 2.0f, Effect.PULL, 120, 15, 1.2, true);
        add("Rogue Planet", "Free-floating planet", ParticleTypes.SCULK_SOUL, ParticleTypes.SQUID_INK, 1.5, 0.010, 2.0f, Effect.DARKEN, 0, 7, 0.8, false);
        add("Exoplanet 51 Pegasi b", "Hot Jupiter", ParticleTypes.FLAME, ParticleTypes.CLOUD, 1.6, 0.015, 3.0f, Effect.BURN, 0, 7, 1.0, false);

        // ---------- Big structures ----------
        add("Orion Nebula", "Nebula", ParticleTypes.WITCH, ParticleTypes.ENCHANT, 1.3, 0.000, 0.0f, Effect.POISON, 100, 10, 2.4, false);
        add("Andromeda Galaxy", "Galaxy", ParticleTypes.END_ROD, ParticleTypes.GLOW, 1.2, 0.000, 2.5f, Effect.GLOW, 80, 12, 2.6, true);
        add("Milky Way", "Galaxy", ParticleTypes.GLOW, ParticleTypes.ENCHANT, 1.2, 0.000, 3.0f, Effect.PULL, 80, 14, 2.8, true);
        add("Crab Nebula", "Supernova remnant", ParticleTypes.WARPED_SPORE, ParticleTypes.SOUL_FIRE_FLAME, 1.3, 0.000, 1.0f, Effect.NAUSEA, 100, 10, 2.0, false);
    }
}
