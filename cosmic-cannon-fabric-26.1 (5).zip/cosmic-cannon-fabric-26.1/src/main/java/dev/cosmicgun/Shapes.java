package dev.cosmicgun;

import net.minecraft.world.phys.Vec3;

/**
 * Particle-built 3D shapes (sphere, torus, cylinder, cone, cube, square pyramid,
 * triangular pyramid, triangular prism). Each shape is sampled as points in a local
 * frame (right / up / forward) and handed to an {@link Emit} callback.
 */
public final class Shapes {
    private Shapes() {}

    @FunctionalInterface
    public interface Emit {
        void at(double x, double y, double z);
    }

    /** Local coordinate frame: r = right, u = up, f = forward. */
    public record Basis(Vec3 r, Vec3 u, Vec3 f) {
        public static Basis of(Vec3 forward) {
            Vec3 f = forward.lengthSqr() < 1.0e-6 ? new Vec3(0, 0, 1) : forward.normalize();
            Vec3 ref = Math.abs(f.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
            Vec3 r = f.cross(ref).normalize();
            Vec3 u = r.cross(f).normalize();
            return new Basis(r, u, f);
        }

        /** Same frame but with the "forward" axis swapped to the old up axis (used for jets). */
        public Basis alongUp() {
            return new Basis(r, f, u);
        }

        Vec3 map(Vec3 c, double x, double y, double z) {
            return c.add(r.scale(x)).add(u.scale(y)).add(f.scale(z));
        }
    }

    private static void put(Vec3 c, Basis b, double x, double y, double z, Emit e) {
        Vec3 p = b.map(c, x, y, z);
        e.at(p.x, p.y, p.z);
    }

    /** Sphere shell (Fibonacci lattice) — evenly spread points that slowly rotate with spin. */
    public static void sphere(Vec3 c, Basis b, double radius, int points, double spin, Emit e) {
        double golden = Math.PI * (3.0 - Math.sqrt(5.0));
        for (int i = 0; i < points; i++) {
            double y = 1.0 - 2.0 * (i + 0.5) / points;
            double ring = Math.sqrt(Math.max(0.0, 1.0 - y * y));
            double phi = i * golden + spin;
            put(c, b, Math.cos(phi) * ring * radius, y * radius, Math.sin(phi) * ring * radius, e);
        }
    }

    /** Flat tilted ring (Saturn-style), axis = local up. */
    public static void ring(Vec3 c, Basis b, double radius, int points, double tilt, double spin, Emit e) {
        for (int i = 0; i < points; i++) {
            double a = spin + (Math.PI * 2.0 * i) / points;
            put(c, b, Math.cos(a) * radius, Math.sin(a) * radius * tilt, Math.sin(a) * radius, e);
        }
    }

    /** Torus (donut): major radius R, tube radius r, axis = local up. */
    public static void torus(Vec3 c, Basis b, double majorR, double minorR, int major, int minor, double spin, Emit e) {
        for (int i = 0; i < major; i++) {
            double u = spin + (Math.PI * 2.0 * i) / major;
            for (int j = 0; j < minor; j++) {
                double v = (Math.PI * 2.0 * j) / minor;
                double d = majorR + minorR * Math.cos(v);
                put(c, b, Math.cos(u) * d, Math.sin(v) * minorR, Math.sin(u) * d, e);
            }
        }
    }

    /** Cylinder along the forward axis. */
    public static void cylinder(Vec3 c, Basis b, double radius, double halfLength, int levels, int ringPoints, double spin, Emit e) {
        for (int l = 0; l < levels; l++) {
            double z = levels == 1 ? 0.0 : -halfLength + (2.0 * halfLength * l) / (levels - 1);
            for (int a = 0; a < ringPoints; a++) {
                double ang = spin + (Math.PI * 2.0 * a) / ringPoints;
                put(c, b, Math.cos(ang) * radius, Math.sin(ang) * radius, z, e);
            }
        }
    }

    /**
     * Cone along the forward axis starting at the centre. Positive length goes forward.
     * expand=true widens away from the centre (muzzle flash); false narrows to a point (comet tail).
     */
    public static void cone(Vec3 c, Basis b, double baseRadius, double length, boolean expand, int arms, int levels, double spin, Emit e) {
        for (int l = 1; l <= levels; l++) {
            double t = (double) l / levels;
            double rad = baseRadius * (expand ? t : (1.0 - t * 0.95));
            double z = length * t;
            for (int a = 0; a < arms; a++) {
                double ang = spin + (Math.PI * 2.0 * a) / arms + l * 0.5;
                put(c, b, Math.cos(ang) * rad, Math.sin(ang) * rad, z, e);
            }
        }
    }

    // ----- wireframe polyhedra -----

    private static void wire(Vec3 c, Basis b, double[][] v, int[][] edges, int perEdge, double spin, Emit e) {
        double cs = Math.cos(spin);
        double sn = Math.sin(spin);
        for (int[] edge : edges) {
            double[] a = v[edge[0]];
            double[] d = v[edge[1]];
            for (int k = 0; k <= perEdge; k++) {
                double t = (double) k / perEdge;
                double x = a[0] + (d[0] - a[0]) * t;
                double y = a[1] + (d[1] - a[1]) * t;
                double z = a[2] + (d[2] - a[2]) * t;
                // spin around the local up axis
                put(c, b, x * cs - z * sn, y, x * sn + z * cs, e);
            }
        }
    }

    public static void cube(Vec3 c, Basis b, double half, double spin, Emit e) {
        double[][] v = new double[8][];
        for (int i = 0; i < 8; i++) {
            v[i] = new double[]{(i & 1) == 0 ? -half : half, (i & 2) == 0 ? -half : half, (i & 4) == 0 ? -half : half};
        }
        int[][] edges = new int[12][];
        int n = 0;
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                int j = i | bit;
                if (j != i) edges[n++] = new int[]{i, j};
            }
        }
        wire(c, b, v, edges, 2, spin, e);
    }

    public static void squarePyramid(Vec3 c, Basis b, double half, double spin, Emit e) {
        double[][] v = {
                {-half, -half, -half}, {half, -half, -half}, {half, -half, half}, {-half, -half, half}, {0, half, 0}
        };
        int[][] edges = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {0, 4}, {1, 4}, {2, 4}, {3, 4}};
        wire(c, b, v, edges, 2, spin, e);
    }

    public static void triangularPyramid(Vec3 c, Basis b, double size, double spin, Emit e) {
        double h = size;
        double[][] v = {
                {-h, -h * 0.6, -h * 0.6}, {h, -h * 0.6, -h * 0.6}, {0, -h * 0.6, h}, {0, h, 0}
        };
        int[][] edges = {{0, 1}, {1, 2}, {2, 0}, {0, 3}, {1, 3}, {2, 3}};
        wire(c, b, v, edges, 2, spin, e);
    }

    public static void triangularPrism(Vec3 c, Basis b, double size, double spin, Emit e) {
        double h = size;
        double[][] v = {
                {-h, -h * 0.6, -h}, {h, -h * 0.6, -h}, {0, h * 0.8, -h},
                {-h, -h * 0.6, h}, {h, -h * 0.6, h}, {0, h * 0.8, h}
        };
        int[][] edges = {{0, 1}, {1, 2}, {2, 0}, {3, 4}, {4, 5}, {5, 3}, {0, 3}, {1, 4}, {2, 5}};
        wire(c, b, v, edges, 2, spin, e);
    }
}
