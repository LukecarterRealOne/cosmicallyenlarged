# COSMIC CANNON — Fabric mod for Minecraft 26.1 – 26.1.2

A sci-fi cannon that fires celestial objects: planets, moons, dwarf planets, comets,
asteroids, stars, neutron stars, pulsars, supernovae, quasars, black holes, nebulae and galaxies.
Each one has its own look, speed, impact explosion and effect.

## Use it
- Get it: `/give @s cosmicgun:cosmic_cannon` (or craft it, see below).
- **Right-click** — fire the selected object.
- **Sneak + right-click** — cycle to the next object (shown on the action bar).

Recipe: iron ingots, diamond, ender eye and a nether star (shaped, see `data/cosmicgun/recipe`).

## Visual effects
- **3D particle shapes** (from the Math Is Fun shape list): spheres for planets and stars, a cube for Asteroid,
  square pyramid for Meteor, triangular prism for Phobos, triangular pyramid for Deimos, a cylinder for 'Oumuamua,
  and tori (donuts) for Black Hole, Magnetar and the galaxies. Saturn-style rings on ringed bodies.
- **Comet tails** (cone) on Meteor and Halley's Comet, **polar jets** (double cone) on Pulsar, Quasar, Black Hole, Magnetar.
- **Muzzle flash** when firing, **expanding shockwave rings/shells** and **spark bursts** on impact.
- **Vortex swirls** in lingering fields (flowing inward for pulls, outward otherwise).

## Notes
- Impacts hurt/affect entities but do not break blocks by default. Set `DESTROY_BLOCKS = true`
  in `ShotManager.java` for TNT-style block damage.
- Black Hole / Quasar / Milky Way pull mobs in; Supernova blasts them away.
- Needs Fabric Loader 0.19.1+, Fabric API for 26.1.x, Java 25. Works in single-player and on servers.
- Not compiled or tested by the author; build with the included GitHub workflow.
