package dev.cosmicgun;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Right-click: fire the selected celestial body.
 * Sneak + right-click: cycle to the next body.
 */
public final class CosmicCannonItem extends Item {
    private static final long COOLDOWN_TICKS = 10;

    private static final Map<UUID, Integer> SELECTED = new HashMap<>();
    private static final Map<UUID, Long> LAST_FIRED = new HashMap<>();

    public CosmicCannonItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        UUID id = player.getUUID();
        int total = CelestialBodies.ALL.size();
        int index = Math.floorMod(SELECTED.getOrDefault(id, 0), total);

        if (player.isShiftKeyDown()) {
            index = (index + 1) % total;
            SELECTED.put(id, index);
            CelestialBodies.Body body = CelestialBodies.ALL.get(index);
            player.displayClientMessage(Component.literal(
                    "[" + (index + 1) + "/" + total + "] " + body.name() + "  -  " + body.kind()), true);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 1.0f + index * 0.02f);
            return InteractionResult.SUCCESS;
        }

        long now = serverLevel.getGameTime();
        Long last = LAST_FIRED.get(id);
        if (last != null && now - last < COOLDOWN_TICKS) {
            return InteractionResult.SUCCESS;
        }
        LAST_FIRED.put(id, now);

        CelestialBodies.Body body = CelestialBodies.ALL.get(index);
        ShotManager.fire(serverLevel, player, body);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.0f, 0.6f);
        player.displayClientMessage(Component.literal("FIRED: " + body.name()), true);
        return InteractionResult.SUCCESS;
    }
}
